<?php

$locales = array(
'maintitle'=>'Assistant d\'installation',
'previousLabel' => 'Précédent',
'nextLabel'=> 'Suivant',


);
